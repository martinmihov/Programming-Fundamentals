﻿using System.Collections.Generic;

namespace _09_Book_Library
{
    public class Library
    {
        public string Name { get; set; }
        public List<Book> Books { get; set; }
    }
}
